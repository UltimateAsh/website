-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : jeu. 11 mai 2023 à 21:18
-- Version du serveur : 10.4.27-MariaDB
-- Version de PHP : 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `projet_bdd`
--

-- --------------------------------------------------------

--
-- Structure de la table `adresse`
--

CREATE TABLE `adresse` (
  `id_adresse` int(11) NOT NULL,
  `nom_adresse` varchar(50) DEFAULT NULL,
  `num_adresse` int(11) DEFAULT NULL,
  `comp_adresse` varchar(50) DEFAULT NULL,
  `id_ville` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `adresse`
--

INSERT INTO `adresse` (`id_adresse`, `nom_adresse`, `num_adresse`, `comp_adresse`, `id_ville`) VALUES
(1, ' Rue du Faubourg', 12, ' ', 6),
(2, ' Rue de la Mairie', 3, ' ', 7),
(3, ' Rue de la Gare', 27, ' ', 2),
(4, ' Avenue des Fleurs', 5, ' Appartement 15', 9),
(5, ' Rue du Marché', 18, ' ', 3),
(6, ' Boulevard du Lac', 10, ' ', 12),
(7, ' Avenue du Soleil', 33, ' ', 11),
(8, ' Rue des Écoles', 7, ' ', 1),
(9, ' Rue des Champs', 2, ' ', 5),
(10, ' Rue de la Fontaine', 9, ' ', 2),
(11, ' Rue du Moulin', 14, ' ', 4),
(12, ' Rue des Lilas', 21, ' ', 8),
(13, ' Rue de la Liberté', 8, ' ', 13),
(14, ' Rue de la Paix', 6, ' ', 7),
(15, ' Rue de la Plage', 20, ' Appartement 4', 12),
(16, ' Avenue de la République', 17, ' ', 1),
(17, ' Rue du Paradis', 13, ' ', 3),
(18, ' Rue de l\'Église', 11, ' ', 9),
(19, ' Rue des Moulins', 16, ' ', 4),
(20, ' Rue des Cerisiers', 22, ' ', 8),
(21, ' Rue des Vignes', 19, ' ', 5),
(22, ' Rue des Châtaigniers', 7, ' Appartement 2', 10),
(23, ' Avenue de la Plaine', 8, ' ', 2),
(24, ' Rue des Prés', 4, ' ', 1),
(25, ' Rue des Sapins', 15, ' ', 6),
(26, ' Rue de la Croix', 23, ' ', 3),
(27, ' Rue du Bois', 1, ' ', 8),
(28, ' Rue des Tulipes', 6, ' ', 13),
(29, ' Rue de la Montagne', 12, ' ', 4),
(30, ' Rue des Roses', 3, ' ', 12),
(31, ' Rue de la Forge', 18, ' ', 5),
(32, ' Rue des Cèdres', 27, ' ', 10),
(33, ' Avenue du Parc', 9, ' ', 9),
(34, ' Rue des Peupliers', 14, ' Appartement 7', 11),
(35, ' Rue des Pommiers', 21, ' ', 8),
(36, ' Rue du Château', 5, ' ', 7),
(37, ' Rue du Canal', 16, ' ', 2),
(38, ' Rue des Bruyères', 10, ' ', 1),
(39, ' Rue des Platanes', 19, ' ', 13),
(40, ' Rue des Bouleaux', 22, ' ', 4),
(41, ' Avenue des Champs-Élysées', 12, ' ', 6),
(42, ' Rue des Jonquilles', 7, ' ', 12),
(43, ' Rue du Parc', 2, ' ', 10),
(44, ' Rue de la Prairie', 6, ' ', 9),
(45, ' Rue des Tilleuls', 14, ' ', 3),
(46, ' Rue des Chênes', 3, ' ', 5),
(47, ' Rue de la Croisette', 21, ' ', 11),
(48, 'Rue de la Forêt', 12, '', 10),
(49, 'Rue des Vignes', 27, '', 11),
(50, 'Rue des Marronniers', 9, '', 8);

-- --------------------------------------------------------

--
-- Structure de la table `agence`
--

CREATE TABLE `agence` (
  `id_agence` int(11) NOT NULL,
  `nom_agence` varchar(50) DEFAULT NULL,
  `id_adresse` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `agence`
--

INSERT INTO `agence` (`id_agence`, `nom_agence`, `id_adresse`) VALUES
(1, 'ÉcoClimat', 8),
(2, 'MétéoVerte', 23),
(3, 'PlanèteMétéo', 45),
(4, 'ÉcoMétéo', 11),
(5, 'ÉcoClimatique', 31),
(6, 'MétéoNaturelle', 1),
(7, 'ÉcoTempête', 14),
(8, 'VertMétéo', 20),
(9, 'ClimatNaturel', 33),
(10, 'ÉcoVent', 48),
(11, 'MétéoÉcologique', 34),
(12, 'ÉcoBaromètre', 42),
(13, 'NatureMétéo', 28);

-- --------------------------------------------------------

--
-- Structure de la table `agent`
--

CREATE TABLE `agent` (
  `id_agent` int(11) NOT NULL,
  `nom_agent` varchar(50) DEFAULT NULL,
  `prenom_agent` varchar(50) DEFAULT NULL,
  `date_recr_agent` date DEFAULT NULL,
  `date_naiss_agent` date DEFAULT NULL,
  `id_adresse` int(11) NOT NULL,
  `id_poste` int(11) NOT NULL,
  `id_agence` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `agent`
--

INSERT INTO `agent` (`id_agent`, `nom_agent`, `prenom_agent`, `date_recr_agent`, `date_naiss_agent`, `id_adresse`, `id_poste`, `id_agence`) VALUES
(1, 'Leblanc', 'Laure', '2019-02-01', '1995-07-12', 19, 1, 5),
(2, 'Dubois', 'Gaëtan', '2020-03-15', '1987-11-23', 6, 2, 10),
(3, 'Bernard', 'Nina', '2021-04-20', '1988-03-08', 27, 3, 7),
(4, 'Robert', 'Daniel', '2022-01-01', '1994-09-29', 37, 1, 9),
(5, 'Petit', 'Madeleine', '2018-06-12', '1985-01-15', 47, 2, 8),
(6, 'Dupont', 'Julien', '2020-11-05', '1992-12-20', 26, 3, 2),
(7, 'Moreau', 'Amélie', '2022-04-10', '1996-08-07', 43, 3, 11),
(8, 'Martin', 'Thomas', '2019-09-23', '1993-05-04', 17, 2, 3),
(9, 'Girard', 'Manon', '2021-07-19', '1990-11-14', 32, 3, 6),
(10, 'André', 'Emmanuel', '2018-08-25', '1986-06-28', 5, 1, 12),
(11, 'Simon', 'Alice', '2020-12-30', '1995-09-17', 49, 2, 13),
(12, 'Michel', 'Lucie', '2022-02-14', '1991-02-24', 25, 3, 4),
(13, 'Durand', 'Marc', '2018-04-02', '1989-04-05', 36, 1, 6),
(14, 'Lefebvre', 'Audrey', '2019-11-18', '1997-01-10', 22, 3, 11),
(15, 'Leroy', 'Guillaume', '2021-05-14', '1993-06-15', 41, 3, 7),
(16, 'Roux', 'Sylvie', '2022-03-07', '1994-11-12', 46, 1, 2),
(17, 'Fournier', 'Antoine', '2018-09-09', '1988-12-09', 15, 2, 9),
(18, 'Morel', 'Marie', '2020-10-11', '1996-02-18', 44, 3, 13),
(19, 'Garcia', 'David', '2021-08-06', '1990-09-03', 39, 1, 5),
(20, 'Lecomte', 'Sandra', '2019-07-07', '1992-04-26', 42, 2, 12);

-- --------------------------------------------------------

--
-- Structure de la table `auteur`
--

CREATE TABLE `auteur` (
  `id_rapport` int(11) NOT NULL,
  `id_agent` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `auteur`
--

INSERT INTO `auteur` (`id_rapport`, `id_agent`) VALUES
(1, 2),
(1, 11),
(1, 23),
(1, 43),
(2, 13),
(2, 15),
(2, 24),
(2, 44),
(3, 3),
(3, 14),
(3, 25),
(3, 45),
(4, 9),
(4, 12),
(4, 26),
(4, 46),
(5, 6),
(5, 17),
(5, 27),
(5, 47),
(6, 13),
(6, 18),
(6, 28),
(6, 48),
(7, 1),
(7, 19),
(7, 29),
(7, 49),
(8, 8),
(8, 16),
(8, 30),
(8, 50),
(9, 19),
(9, 20),
(9, 31),
(9, 51),
(10, 15),
(10, 17),
(10, 32),
(10, 52),
(11, 4),
(11, 10),
(11, 33),
(12, 9),
(12, 14),
(12, 34),
(13, 8),
(13, 16),
(13, 35),
(14, 7),
(14, 36),
(15, 5),
(15, 6),
(15, 37),
(16, 5),
(16, 11),
(16, 38),
(17, 4),
(17, 18),
(17, 39),
(18, 3),
(18, 10),
(18, 40),
(19, 2),
(19, 12),
(19, 41),
(20, 1),
(20, 20),
(20, 42);

-- --------------------------------------------------------

--
-- Structure de la table `capteur`
--

CREATE TABLE `capteur` (
  `id_capteur` int(11) NOT NULL,
  `id_adresse` int(11) NOT NULL,
  `id_agent` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `capteur`
--

INSERT INTO `capteur` (`id_capteur`, `id_adresse`, `id_agent`) VALUES
(1, 40, 5),
(2, 16, 13),
(3, 29, 9),
(4, 35, 4),
(5, 10, 19),
(6, 21, 1),
(7, 37, 10),
(8, 9, 15),
(9, 38, 11),
(10, 2, 8),
(11, 30, 6),
(12, 18, 3),
(13, 3, 7),
(14, 24, 20),
(15, 19, 18),
(16, 12, 2),
(17, 4, 14),
(18, 7, 12),
(19, 13, 17),
(20, 21, 15);

-- --------------------------------------------------------

--
-- Structure de la table `gaz`
--

CREATE TABLE `gaz` (
  `id_gaz` int(11) NOT NULL,
  `type_gaz` varchar(50) DEFAULT NULL,
  `mol_gaz` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `gaz`
--

INSERT INTO `gaz` (`id_gaz`, `type_gaz`, `mol_gaz`) VALUES
(1, 'GES', 'CH4'),
(2, 'GES', 'N2O'),
(3, 'GES', 'PFC'),
(4, 'GES', 'HFC'),
(5, 'GES', 'SF6'),
(6, 'GRA', 'SO2'),
(7, 'GRA', 'Nox'),
(8, 'GRA', 'NH3'),
(9, 'GRA', 'CO'),
(10, 'GRA', 'COVNM'),
(11, 'GES', 'CO2'),
(12, 'GES', 'CO2bio');

-- --------------------------------------------------------

--
-- Structure de la table `mesure`
--

CREATE TABLE `mesure` (
  `id_gaz` int(11) NOT NULL,
  `id_capteur` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `mesure`
--

INSERT INTO `mesure` (`id_gaz`, `id_capteur`) VALUES
(1, 1),
(1, 4),
(1, 8),
(1, 9),
(1, 14),
(1, 17),
(1, 18),
(2, 2),
(2, 8),
(2, 10),
(2, 11),
(2, 18),
(3, 3),
(3, 5),
(3, 9),
(3, 11),
(3, 13),
(3, 19),
(4, 4),
(4, 5),
(4, 9),
(4, 12),
(4, 14),
(4, 20),
(5, 5),
(5, 10),
(5, 13),
(5, 16),
(6, 3),
(6, 6),
(6, 14),
(6, 19),
(7, 1),
(7, 6),
(7, 11),
(7, 14),
(7, 20),
(8, 2),
(8, 6),
(8, 7),
(8, 13),
(8, 14),
(8, 15),
(9, 1),
(9, 7),
(9, 15),
(10, 2),
(10, 6),
(10, 8),
(10, 16),
(11, 1),
(11, 2),
(11, 3),
(11, 4),
(11, 5),
(11, 6),
(11, 7),
(11, 8),
(11, 9),
(11, 10),
(11, 11),
(11, 12),
(11, 13),
(11, 14),
(11, 15),
(11, 16),
(11, 17),
(11, 18),
(11, 19),
(11, 20),
(12, 12);

-- --------------------------------------------------------

--
-- Structure de la table `pollution`
--

CREATE TABLE `pollution` (
  `id_pol` int(11) NOT NULL,
  `donnée_pol` decimal(15,2) DEFAULT NULL,
  `id_région` int(11) NOT NULL,
  `id_sec` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `pollution`
--

INSERT INTO `pollution` (`id_pol`, `donnée_pol`, `id_région`, `id_sec`) VALUES
(1, '2316478.00', 1, 1),
(2, '1356065.00', 2, 1),
(3, '382886.00', 3, 1),
(4, '477481.00', 4, 1),
(5, '737534.00', 5, 1),
(6, '11437807.00', 6, 1),
(7, '10102917.00', 7, 1),
(8, '7193219.00', 8, 1),
(9, '11004908.00', 9, 1),
(10, '970878.00', 10, 1),
(11, '899459.00', 11, 1),
(12, '6120492.00', 12, 1),
(13, '8322984.00', 13, 1),
(14, '11084127.00', 1, 2),
(15, '4528159.00', 2, 2),
(16, '4524539.00', 3, 2),
(17, '3745601.00', 4, 2),
(18, '184606.00', 5, 2),
(19, '9519243.00', 6, 2),
(20, '8941196.00', 7, 2),
(21, '15461749.00', 8, 2),
(22, '4921582.00', 9, 2),
(23, '7349368.00', 10, 2),
(24, '6184092.00', 11, 2),
(25, '4604353.00', 12, 2),
(26, '4977623.00', 13, 2),
(27, '8113875.00', 1, 3),
(28, '2814532.00', 2, 3),
(29, '2154157.00', 3, 3),
(30, '2536467.00', 4, 3),
(31, '38782.00', 5, 3),
(32, '11352094.00', 6, 3),
(33, '13343225.00', 7, 3),
(34, '5575618.00', 8, 3),
(35, '5014025.00', 9, 3),
(36, '5284753.00', 10, 3),
(37, '3354206.00', 11, 3),
(38, '3073018.00', 12, 3),
(39, '10290764.00', 13, 3),
(40, '2982089.00', 1, 4),
(41, '421641.00', 2, 4),
(42, '8695.00', 3, 4),
(43, '594181.00', 4, 4),
(44, '36.00', 5, 4),
(45, '7037205.00', 6, 4),
(46, '4853694.00', 7, 4),
(47, '1525788.00', 8, 4),
(48, '3985929.00', 9, 4),
(49, '1922844.00', 10, 4),
(50, '1674090.00', 11, 4),
(51, '1463991.00', 12, 4),
(52, '3342771.00', 13, 4),
(53, '210314.00', 1, 5),
(54, '80446.00', 2, 5),
(55, '57663.00', 3, 5),
(56, '71020.00', 4, 5),
(57, '0.00', 5, 5),
(58, '260488.00', 6, 5),
(59, '307274.00', 7, 5),
(60, '384133.00', 8, 5),
(61, '175113.00', 9, 5),
(62, '525046.00', 10, 5),
(63, '101517.00', 11, 5),
(64, '82822.00', 12, 5),
(65, '112308.00', 13, 5),
(66, '1682398.00', 1, 6),
(67, '607013.00', 2, 6),
(68, '797999.00', 3, 6),
(69, '515513.00', 4, 6),
(70, '82646.00', 5, 6),
(71, '1480650.00', 6, 6),
(72, '1407607.00', 7, 6),
(73, '2719843.00', 8, 6),
(74, '829685.00', 9, 6),
(75, '1241785.00', 10, 6),
(76, '1123520.00', 11, 6),
(77, '784981.00', 12, 6),
(78, '1073305.00', 13, 6),
(79, '17867684.00', 1, 7),
(80, '8656852.00', 2, 7),
(81, '6699501.00', 3, 7),
(82, '7267081.00', 4, 7),
(83, '568139.00', 5, 7),
(84, '13602971.00', 6, 7),
(85, '11895044.00', 7, 7),
(86, '14386164.00', 8, 7),
(87, '7323971.00', 9, 7),
(88, '14627798.00', 10, 7),
(89, '13586519.00', 11, 7),
(90, '7601374.00', 12, 7),
(91, '9499426.00', 13, 7),
(92, '1144755.00', 1, 8),
(93, '989104.00', 2, 8),
(94, '609869.00', 3, 8),
(95, '969958.00', 4, 8),
(96, '30726.00', 5, 8),
(97, '1383457.00', 6, 8),
(98, '1086406.00', 7, 8),
(99, '509137.00', 8, 8),
(100, '905155.00', 9, 8),
(101, '1416722.00', 10, 8),
(102, '931659.00', 11, 8),
(103, '883086.00', 12, 8),
(104, '288198.00', 13, 8),
(105, '1607165.00', 1, 9),
(106, '604356.00', 2, 9),
(107, '463705.00', 3, 9),
(108, '494149.00', 4, 9),
(109, '38149.00', 5, 9),
(110, '897350.00', 6, 9),
(111, '1192466.00', 7, 9),
(112, '1439175.00', 8, 9),
(113, '648698.00', 9, 9),
(114, '961097.00', 10, 9),
(115, '931700.00', 11, 9),
(116, '493394.00', 12, 9),
(117, '1048926.00', 13, 9),
(118, '6968656.00', 1, 10),
(119, '5365922.00', 2, 10),
(120, '8103809.00', 3, 10),
(121, '3584354.00', 4, 10),
(122, '188003.00', 5, 10),
(123, '7222080.00', 6, 10),
(124, '6274957.00', 7, 10),
(125, '707778.00', 8, 10),
(126, '6974736.00', 9, 10),
(127, '8871441.00', 10, 10),
(128, '5165396.00', 11, 10),
(129, '7529952.00', 12, 10),
(130, '578784.00', 13, 10),
(131, '338195.00', 1, 11),
(132, '322366.00', 2, 11),
(133, '152976.00', 3, 11),
(134, '183691.00', 4, 11),
(135, '19694.00', 5, 11),
(136, '462417.00', 6, 11),
(137, '211246.00', 7, 11),
(138, '45313.00', 8, 11),
(139, '142767.00', 9, 11),
(140, '488029.00', 10, 11),
(141, '349152.00', 11, 11),
(142, '205482.00', 12, 11),
(143, '113217.00', 13, 11);

-- --------------------------------------------------------

--
-- Structure de la table `poste`
--

CREATE TABLE `poste` (
  `id_poste` int(11) NOT NULL,
  `nom_poste` varchar(50) DEFAULT NULL,
  `desc_poste` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `poste`
--

INSERT INTO `poste` (`id_poste`, `nom_poste`, `desc_poste`) VALUES
(1, 'chef', 'Chef'),
(2, 'tech', 'Technicien'),
(3, 'admin', 'Administration');

-- --------------------------------------------------------

--
-- Structure de la table `rapport`
--

CREATE TABLE `rapport` (
  `id_rapport` int(11) NOT NULL,
  `titre_rapport` varchar(50) DEFAULT NULL,
  `date_rapport` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `rapport`
--

INSERT INTO `rapport` (`id_rapport`, `titre_rapport`, `date_rapport`) VALUES
(1, 'Pollution atmosphérique en Île-de-France', '2021-05-12'),
(2, 'Impact de l\'industrie sur la qualité de l\'air en B', '2020-11-20'),
(3, 'Pollution de l\'eau potable dans la région PACA', '2022-02-05'),
(4, 'Évaluation de la pollution sonore à Marseille', '2019-08-14'),
(5, 'Qualité de l\'air dans les grandes villes française', '2021-10-30'),
(6, 'Impact de l\'agriculture sur la pollution des sols', '2022-04-22'),
(7, 'Pollution lumineuse dans les zones touristiques', '2020-06-03'),
(8, 'Évaluation de la qualité de l\'air dans les écoles', '2019-11-29'),
(9, 'Pollution des rivières en Normandie', '2022-03-17'),
(10, 'Mesure de la pollution des plages en été', '2021-07-08'),
(11, 'Impact de l\'urbanisation sur la qualité de l\'air', '2019-06-22'),
(12, 'Pollution de l\'air en période de canicule', '2020-08-09'),
(13, 'Évaluation de la qualité de l\'eau de boisson en Al', '2021-03-11'),
(14, 'Pollution de l\'air dans les transports en commun', '2019-12-30'),
(15, 'Pollution plastique en Méditerranée', '2022-01-28'),
(16, 'Impact de l\'industrie minière sur la pollution des', '2021-02-19'),
(17, 'Qualité de l\'air en zone rurale', '2020-05-16'),
(18, 'Pollution des sols par les pesticides en Gironde', '2022-04-05'),
(19, 'Évaluation de la pollution de l\'eau de boisson en ', '2019-09-07'),
(20, 'Pollution de l\'air en zone industrielle', '2021-12-14');

-- --------------------------------------------------------

--
-- Structure de la table `relevé`
--

CREATE TABLE `relevé` (
  `id_releve` int(11) NOT NULL,
  `date_releve` date DEFAULT NULL,
  `donnee_releve` decimal(15,2) DEFAULT NULL,
  `id_gaz` int(11) NOT NULL,
  `id_capteur` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `relevé`
--

INSERT INTO `relevé` (`id_releve`, `date_releve`, `donnee_releve`, `id_gaz`, `id_capteur`) VALUES
(1, '2018-11-20', '0.32', 3, 5),
(2, '2018-04-02', '1.68', 4, 9),
(3, '2019-07-13', '222.35', 10, 6),
(4, '2017-01-11', '0.01', 1, 8),
(5, '2018-08-18', '36.79', 8, 15),
(6, '2021-12-01', '0.00', 6, 19),
(7, '2022-03-25', '667.23', 11, 9),
(8, '2017-11-05', '0.03', 1, 4),
(9, '2016-09-28', '0.00', 12, 12),
(10, '2020-10-09', '567.01', 11, 10),
(11, '2023-05-08', '0.46', 6, 6),
(12, '2022-06-30', '2.33', 5, 10),
(13, '2016-08-06', '0.00', 9, 7),
(14, '2017-10-01', '0.00', 8, 7),
(15, '2022-05-19', '345.67', 11, 16),
(16, '2017-12-12', '0.00', 3, 19),
(17, '2020-07-26', '12.23', 5, 16),
(18, '2022-04-14', '543.21', 11, 3),
(19, '2019-06-17', '99.79', 7, 1),
(20, '2017-06-28', '0.00', 8, 2),
(21, '2020-01-22', '345.00', 11, 11),
(22, '2017-02-18', '0.00', 4, 5),
(23, '2019-03-15', '5.68', 7, 6),
(24, '2017-07-30', '0.00', 8, 14),
(25, '2016-12-24', '0.00', 9, 1),
(26, '2018-05-31', '0.01', 8, 6),
(27, '2020-02-17', '899.32', 10, 2),
(28, '2022-11-09', '234.00', 3, 5),
(29, '2018-02-28', '0.57', 8, 14),
(30, '2023-01-11', '15.12', 2, 2),
(31, '2018-06-13', '0.35', 3, 13),
(32, '2016-11-04', '0.00', 12, 12),
(33, '2017-09-22', '0.02', 8, 7),
(34, '2019-11-01', '456.12', 11, 1),
(35, '2021-05-31', '0.05', 6, 14),
(36, '2022-09-12', '345.79', 11, 14),
(37, '2019-01-18', '0.00', 9, 15),
(38, '2021-02-27', '100.88', 7, 20),
(39, '2018-10-08', '0.01', 4, 4),
(40, '2020-08-13', '192.00', 9, 1),
(41, '2020-02-25', '57.94', 7, 1),
(42, '2019-08-12', '0.00', 8, 2),
(43, '2017-11-20', '42.56', 6, 3),
(44, '2019-06-07', '676.01', 11, 4),
(45, '2016-10-15', '0.00', 3, 5),
(46, '2018-09-01', '999.84', 10, 6),
(47, '2017-05-27', '815.19', 9, 7),
(48, '2021-03-09', '0.01', 1, 8),
(49, '2022-06-11', '0.10', 4, 9),
(50, '2017-08-03', '0.01', 5, 10),
(51, '2020-11-22', '45.32', 1, 5),
(52, '2019-08-09', '0.01', 2, 8),
(53, '2022-02-14', '53.79', 3, 13),
(54, '2018-10-01', '0.04', 4, 14),
(55, '2017-05-25', '620.07', 5, 13),
(56, '2021-06-07', '7.85', 6, 3),
(57, '2023-01-10', '0.00', 7, 20),
(58, '2017-12-31', '89.12', 8, 7),
(59, '2022-07-22', '200.24', 9, 15),
(60, '2018-03-16', '0.00', 10, 6);

-- --------------------------------------------------------

--
-- Structure de la table `relevés_dans_rapport`
--

CREATE TABLE `relevés_dans_rapport` (
  `id_rapport` int(11) NOT NULL,
  `id_releve` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `relevés_dans_rapport`
--

INSERT INTO `relevés_dans_rapport` (`id_rapport`, `id_releve`) VALUES
(1, 1),
(1, 2),
(1, 3),
(2, 4),
(2, 5),
(3, 6),
(3, 7),
(3, 8),
(4, 9),
(5, 10),
(6, 11),
(7, 12),
(7, 13),
(8, 14),
(9, 15),
(9, 16),
(9, 17),
(10, 18),
(11, 19),
(12, 20),
(12, 21),
(13, 22),
(13, 23),
(14, 24),
(15, 25),
(16, 26),
(17, 27),
(18, 28),
(19, 29),
(20, 30);

-- --------------------------------------------------------

--
-- Structure de la table `région`
--

CREATE TABLE `région` (
  `id_région` int(11) NOT NULL,
  `nom_region` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `région`
--

INSERT INTO `région` (`id_région`, `nom_region`) VALUES
(1, 'Auvergne-Rhône-Alpes'),
(2, 'Bourgogne-Franche-Comté'),
(3, 'Bretagne'),
(4, 'Centre-Val de Loire'),
(5, 'Corse'),
(6, 'Grand Est'),
(7, 'Hauts-de-France'),
(8, 'Île-de-France'),
(9, 'Normandie'),
(10, 'Nouvelle-Aquitaine'),
(11, 'Occitanie'),
(12, 'Pays de la Loire'),
(13, 'Provence-Alpes-Côte d\'Azur');

-- --------------------------------------------------------

--
-- Structure de la table `secteur`
--

CREATE TABLE `secteur` (
  `id_sec` int(11) NOT NULL,
  `nom_sec` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `secteur`
--

INSERT INTO `secteur` (`id_sec`, `nom_sec`) VALUES
(1, 'Combustion dans les industries de l\'energie et de la transformation de l\'energie'),
(2, 'Combustion hors industrie'),
(3, 'Combustion dans l\'industrie manufacturiere'),
(4, 'Procedes de production'),
(5, 'Extraction et distribution de combustibles fossile'),
(6, 'Utilisation de solvants et autres produits'),
(7, 'Transport routier'),
(8, 'Autres sources mobiles et machines'),
(9, 'Traitement et elimination des dechets'),
(10, 'Agriculture et sylviculture'),
(11, 'Autres sources biotiques');

-- --------------------------------------------------------

--
-- Structure de la table `ville`
--

CREATE TABLE `ville` (
  `id_ville` int(11) NOT NULL,
  `nom_ville` varchar(50) DEFAULT NULL,
  `id_région` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `ville`
--

INSERT INTO `ville` (`id_ville`, `nom_ville`, `id_région`) VALUES
(1, 'Lyon', 1),
(2, 'Dijon', 2),
(3, 'Rennes', 3),
(4, 'Orléans', 4),
(5, 'Ajaccio', 5),
(6, 'Strasbourg', 6),
(7, 'Lille', 7),
(8, 'Paris', 8),
(9, 'Rouen', 9),
(10, 'Bordeaux', 10),
(11, 'Toulouse', 11),
(12, 'Nantes', 12),
(13, 'Marseille', 13);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `adresse`
--
ALTER TABLE `adresse`
  ADD PRIMARY KEY (`id_adresse`),
  ADD KEY `id_ville` (`id_ville`);

--
-- Index pour la table `agence`
--
ALTER TABLE `agence`
  ADD PRIMARY KEY (`id_agence`),
  ADD KEY `id_adresse` (`id_adresse`);

--
-- Index pour la table `agent`
--
ALTER TABLE `agent`
  ADD PRIMARY KEY (`id_agent`),
  ADD KEY `id_adresse` (`id_adresse`),
  ADD KEY `id_poste` (`id_poste`),
  ADD KEY `id_agence` (`id_agence`);

--
-- Index pour la table `auteur`
--
ALTER TABLE `auteur`
  ADD PRIMARY KEY (`id_rapport`,`id_agent`),
  ADD KEY `id_agent` (`id_agent`);

--
-- Index pour la table `capteur`
--
ALTER TABLE `capteur`
  ADD PRIMARY KEY (`id_capteur`),
  ADD KEY `id_adresse` (`id_adresse`),
  ADD KEY `id_agent` (`id_agent`);

--
-- Index pour la table `gaz`
--
ALTER TABLE `gaz`
  ADD PRIMARY KEY (`id_gaz`);

--
-- Index pour la table `mesure`
--
ALTER TABLE `mesure`
  ADD PRIMARY KEY (`id_gaz`,`id_capteur`),
  ADD KEY `id_capteur` (`id_capteur`);

--
-- Index pour la table `pollution`
--
ALTER TABLE `pollution`
  ADD PRIMARY KEY (`id_pol`),
  ADD KEY `id_région` (`id_région`),
  ADD KEY `id_sec` (`id_sec`);

--
-- Index pour la table `poste`
--
ALTER TABLE `poste`
  ADD PRIMARY KEY (`id_poste`);

--
-- Index pour la table `rapport`
--
ALTER TABLE `rapport`
  ADD PRIMARY KEY (`id_rapport`);

--
-- Index pour la table `relevé`
--
ALTER TABLE `relevé`
  ADD PRIMARY KEY (`id_releve`),
  ADD UNIQUE KEY `id_capteur` (`id_capteur`,`date_releve`) USING BTREE,
  ADD KEY `id_gaz` (`id_gaz`);

--
-- Index pour la table `relevés_dans_rapport`
--
ALTER TABLE `relevés_dans_rapport`
  ADD PRIMARY KEY (`id_rapport`,`id_releve`),
  ADD KEY `id_releve` (`id_releve`);

--
-- Index pour la table `région`
--
ALTER TABLE `région`
  ADD PRIMARY KEY (`id_région`);

--
-- Index pour la table `secteur`
--
ALTER TABLE `secteur`
  ADD PRIMARY KEY (`id_sec`);

--
-- Index pour la table `ville`
--
ALTER TABLE `ville`
  ADD PRIMARY KEY (`id_ville`),
  ADD KEY `id_région` (`id_région`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `adresse`
--
ALTER TABLE `adresse`
  ADD CONSTRAINT `adresse_ibfk_1` FOREIGN KEY (`id_ville`) REFERENCES `ville` (`id_ville`);

--
-- Contraintes pour la table `agence`
--
ALTER TABLE `agence`
  ADD CONSTRAINT `agence_ibfk_1` FOREIGN KEY (`id_adresse`) REFERENCES `adresse` (`id_adresse`);

--
-- Contraintes pour la table `agent`
--
ALTER TABLE `agent`
  ADD CONSTRAINT `agent_ibfk_1` FOREIGN KEY (`id_adresse`) REFERENCES `adresse` (`id_adresse`),
  ADD CONSTRAINT `agent_ibfk_2` FOREIGN KEY (`id_poste`) REFERENCES `poste` (`id_poste`),
  ADD CONSTRAINT `agent_ibfk_3` FOREIGN KEY (`id_agence`) REFERENCES `agence` (`id_agence`);

--
-- Contraintes pour la table `auteur`
--
ALTER TABLE `auteur`
  ADD CONSTRAINT `auteur_ibfk_1` FOREIGN KEY (`id_rapport`) REFERENCES `rapport` (`id_rapport`),
  ADD CONSTRAINT `auteur_ibfk_2` FOREIGN KEY (`id_agent`) REFERENCES `agent` (`id_agent`);

--
-- Contraintes pour la table `capteur`
--
ALTER TABLE `capteur`
  ADD CONSTRAINT `capteur_ibfk_1` FOREIGN KEY (`id_adresse`) REFERENCES `adresse` (`id_adresse`),
  ADD CONSTRAINT `capteur_ibfk_2` FOREIGN KEY (`id_agent`) REFERENCES `agent` (`id_agent`);

--
-- Contraintes pour la table `mesure`
--
ALTER TABLE `mesure`
  ADD CONSTRAINT `mesure_ibfk_1` FOREIGN KEY (`id_gaz`) REFERENCES `gaz` (`id_gaz`),
  ADD CONSTRAINT `mesure_ibfk_2` FOREIGN KEY (`id_capteur`) REFERENCES `capteur` (`id_capteur`);

--
-- Contraintes pour la table `pollution`
--
ALTER TABLE `pollution`
  ADD CONSTRAINT `pollution_ibfk_1` FOREIGN KEY (`id_région`) REFERENCES `région` (`id_région`),
  ADD CONSTRAINT `pollution_ibfk_2` FOREIGN KEY (`id_sec`) REFERENCES `secteur` (`id_sec`);

--
-- Contraintes pour la table `relevé`
--
ALTER TABLE `relevé`
  ADD CONSTRAINT `relevé_ibfk_1` FOREIGN KEY (`id_gaz`) REFERENCES `gaz` (`id_gaz`),
  ADD CONSTRAINT `relevé_ibfk_2` FOREIGN KEY (`id_capteur`) REFERENCES `capteur` (`id_capteur`);

--
-- Contraintes pour la table `relevés_dans_rapport`
--
ALTER TABLE `relevés_dans_rapport`
  ADD CONSTRAINT `relevés_dans_rapport_ibfk_1` FOREIGN KEY (`id_rapport`) REFERENCES `rapport` (`id_rapport`),
  ADD CONSTRAINT `relevés_dans_rapport_ibfk_2` FOREIGN KEY (`id_releve`) REFERENCES `relevé` (`id_releve`);

--
-- Contraintes pour la table `ville`
--
ALTER TABLE `ville`
  ADD CONSTRAINT `ville_ibfk_1` FOREIGN KEY (`id_région`) REFERENCES `région` (`id_région`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
