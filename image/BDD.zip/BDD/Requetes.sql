/* #1 */
DELIMITER //
CREATE PROCEDURE requete1()
BEGIN
SELECT nom_agence FROM Agence;
END //
DELIMITER;

/* #2 */
DELIMITER //
CREATE PROCEDURE requete2()
BEGIN
SELECT nom_agent, prenom_agent
FROM Agence as agc 
JOIN Agent as agt ON agt.id_agence=agc.id_agence
JOIN Adresse as ad ON ad.id_adresse=agc.id_adresse
JOIN Ville as v ON v.id_ville = ad.id_ville
JOIN poste as post ON post.id_poste = agt.id_poste
WHERE nom_poste = 'tech' AND nom_ville = 'Bordeaux';
END //
DELIMITER;

/* #3 */
DELIMITER //
CREATE PROCEDURE requete3()
BEGIN
SELECT COUNT(*) FROM Capteur;
END //
DELIMITER;

/* #4 */
DELIMITER //
CREATE PROCEDURE requete4()
BEGIN
SELECT titre_rapport FROM Rapport WHERE YEAR(date_rapport) BETWEEN 2018 AND 2022;
END //
DELIMITER;

/* #5 */
DELIMITER //
CREATE PROCEDURE requete5()
BEGIN
SELECT g.mol_gaz,SUM(donnee_releve),rg.nom_region
FROM Relevé as rlv
JOIN Capteur as c ON c.id_capteur=rlv.id_capteur
JOIN Adresse as ad ON c.id_adresse = ad.id_adresse
JOIN Ville as v ON v.id_ville = ad.id_ville
JOIN Région as rg ON rg.id_région = v.id_région
JOIN Gaz as g ON g.id_gaz = rlv.id_gaz
WHERE YEAR(rlv.date_releve) = '2020' AND g.type_gaz = 'GES'
GROUP BY rg.id_région;
END //
DELIMITER;

/* #6 */
DELIMITER //
CREATE PROCEDURE requete6()
BEGIN
SELECT sec.nom_sec
FROM Secteur as sec
JOIN Pollution as pol ON sec.id_sec = pol.id_sec
JOIN Région as rg ON pol.id_région = rg.id_région
WHERE rg.nom_region = 'Île-de-France'
AND pol.donnée_pol = (
  SELECT MAX(pol.donnée_pol)
  FROM Pollution as pol
  JOIN Région as rg ON pol.id_région = rg.id_région
  WHERE rg.nom_region = 'Île-de-France'
);
END //
DELIMITER;

/* #7 */
DELIMITER //
CREATE PROCEDURE requete7()
BEGIN
SELECT DISTINCT titre_rapport
FROM Rapport as rpt
JOIN relevés_dans_rapport as rdr ON rdr.id_rapport = rpt.id_rapport
JOIN Relevé as rlv ON rlv.id_releve = rdr.id_releve
JOIN Gaz as g ON g.id_gaz=rlv.id_gaz
WHERE g.mol_gaz='NH3'
ORDER BY rlv.date_releve ASC;
END //
DELIMITER;

/* #8 */
DELIMITER //
CREATE PROCEDURE requete8()
BEGIN
SELECT nom_agent, prenom_agent
FROM Agent as agt
JOIN Capteur as c ON agt.id_agent = c.id_agent
JOIN Mesure as m ON c.id_capteur = m.id_gaz
JOIN Gaz as g ON m.id_gaz = g.id_gaz
WHERE g.type_gaz = 'GRA'
GROUP BY nom_agent, prenom_agent;
END //
DELIMITER;

/* #9 */
DELIMITER //
CREATE PROCEDURE requete9()
BEGIN
SELECT g.mol_gaz, SUM(rlv.donnee_releve)
FROM Relevé as rlv
JOIN Gaz as g ON g.id_gaz = rlv.id_gaz
JOIN Capteur as c ON c.id_capteur = rlv.id_capteur
JOIN Adresse as ad ON c.id_adresse = ad.id_adresse
JOIN Ville as v ON v.id_ville = ad.id_ville
JOIN Région as rg ON rg.id_région = v.id_région
WHERE rg.nom_region = 'Île-de-France' AND YEAR(rlv.date_releve) = 2020
GROUP BY g.id_gaz;
END //
DELIMITER;

/* #10 */
DELIMITER //
CREATE PROCEDURE requete10()
BEGIN
SELECT agt.nom_agent, agt.prenom_agent,
COUNT(rpt.id_rapport) / (YEAR(NOW())-YEAR(agt.date_recr_agent)) AS "Taux de productivité"
FROM Rapport as rpt
JOIN Auteur as aut ON aut.id_rapport = rpt.id_rapport
JOIN Agent as agt ON agt.id_agent = aut.id_agent
JOIN Agence as agc ON agc.id_agence = agt.id_agence
JOIN Adresse as ad ON agc.id_adresse = ad.id_adresse
JOIN Ville as v ON v.id_ville = ad.id_ville
JOIN Poste as post on post.id_poste = agt.id_poste
WHERE v.nom_ville = 'Toulouse' AND post.nom_poste = 'admin'
GROUP BY agt.id_agent;
END //
DELIMITER;

/* #11 */
DELIMITER //
CREATE PROCEDURE requete11(IN mol VARCHAR(50))
BEGIN
SELECT titre_rapport
FROM Rapport as rpt
JOIN relevés_dans_rapport as rdr ON rdr.id_rapport = rpt.id_rapport
JOIN Relevé as rlv ON rlv.id_releve = rdr.id_releve
JOIN Gaz as g ON rlv.id_gaz = g.id_gaz
WHERE mol_gaz = mol COLLATE utf8mb4_0900_ai_ci;
END //
DELIMITER;


/* #12 */
DELIMITER //
CREATE PROCEDURE requete12()
BEGIN
SELECT agcs.nom_region FROM
(SELECT rg.nom_region, COUNT(agc.id_agence) as nb
FROM Région as rg
JOIN Ville as v on v.id_région = rg.id_région
JOIN Adresse as ad on ad.id_ville = v.id_ville
JOIN Agence as agc ON ad.id_adresse = agc.id_adresse
GROUP BY rg.id_région) as agcs 
LEFT JOIN
(SELECT rg.nom_region, COUNT(c.id_capteur) as nb
FROM Région as rg
JOIN Ville as v on v.id_région = rg.id_région
JOIN Adresse as ad on ad.id_ville = v.id_ville
JOIN Capteur as c ON ad.id_adresse = c.id_capteur
GROUP BY rg.id_région) as cs
ON agcs.nom_region = cs.nom_region
WHERE COALESCE(cs.nb, 0)<agcs.nb;
END //