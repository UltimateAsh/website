#include "Arduino.h"
#include <SD.h>
#include <RTClib.h>
#include <DHT.h>
#include <stdlib.h>
#include <EEPROM.h>
// #include <TinyGPS.h>
// #include <SoftwareSerial.h>

void createOrSwitchLogFile();
void InitializeSTAND();
void Execute();
//void readGPSLatitudeLongitude(char* latitude, char* longitude);
void readDHTData(char* temp, char* hum);
void readLightSensor(char* lum);
void logDataToSD(DateTime timestamp, char* temp, char* hum, char* lum/*, char* lat, char* lon*/);
void errorLED(bool *);


