#include "standard.h"
void mode_maintenance(void);
void printArray(char *);