#include "fonctions.h"
#include "ModeMaintenance.h"
#include "standard.h"
#include "config.h"
#include <SD.h>
#define wait_user() while(!Serial.available() && currentState==MAINT){}
#define sd_port 4

char temperatureMaint[10];
char humuditeMaint[10];
char luminositeMaint[10];

void mode_maintenance(){
    SD.end();
  	Serial.println(F(
        "\nMode maintenance :"
        "Quel capteur voulez vous afficher ?\n"
        "0 : Température\n"
        "1 : Humidité\n"
        "2 : Luminosité\n"
    ));
    wait_user();
    readDHTData(temperatureMaint, humuditeMaint);
    readLightSensor(luminositeMaint);
    switch(Serial.parseInt()){
    	case 0: 
        Serial.print(F("Capteur de température : "));
        printArray(temperatureMaint);
        Serial.println(F(" °C."));
        break;
      case 1: 
        Serial.print(F("Capteur d'humidité : "));
        printArray(humuditeMaint);
        Serial.println(F(" %"));
        break;
      case 2: 
        Serial.print(F("Capteur de luminosité : "));
        printArray(luminositeMaint);
        Serial.println(F(""));
        break;
      default: Serial.println(F("Choix non valide")); break;
    }
    Serial.read();
}

void printArray(char *Input){
  for(int i=0 ; i < strlen(Input) ; i++){
    Serial.print(Input[i]);
  }
}