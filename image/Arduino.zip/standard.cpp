#include "standard.h"
#include "fonctions.h"

RTC_DS1307 rtc;
File dataFile;

#define chipSelect 4
#define lightSensorPin A0
#define DHTPIN 6
#define DHTTYPE DHT11

#define error_rtc 255,0,0,0,0,255
#define error_capt_access 255,0,0,0,255,0
#define error_capt_weird 255,0,0,0,255,0
#define error_sd_full 255,0,0,255,255,255
#define error_sd_access 255,0,0,255,255,255

bool ERROR[5] = {0,0,0,0,0};

int FILE_MAX_S;

//Capteur luminosité
bool LUMIN;
int LUMIN_LOW;
int LUMIN_HIGH;

//Capteur temp. air
bool TEMP_AIR;
int MIN_TEMP_AIR;
int MAX_TEMP_AIR;

//Capteur hygrométrie
bool HYGR;
int HYGR_MINT;
int HYGR_MAXT;

DHT dht(DHTPIN, DHTTYPE);
// TinyGPS gps;
// SoftwareSerial ss(3,4);

int lastReadTimeSensors = 0;
int revisionNumber = 7;

float temp_hum_val[2] = {0};

char temperature[10];  // Char array to store temperature
char humidity[10];     // Char array to store humidity
char luminosity[10];   // Char array to store luminosity
//char gpsLatitude[20];  // Char array to store GPS latitude
//char gpsLongitude[20]; // Char array to store GPS longitude

char filename[15]; // Char array to store the filename

void getFilename() {
  DateTime now = rtc.now();
  EEPROM.get(3,FILE_MAX_S); 
  //Serial.println(FILE_MAX_S);
  if (dataFile && dataFile.size() >= FILE_MAX_S) {
    Serial.println(F("Fichier plein"));
    revisionNumber++;
  }

  snprintf(filename, 15, "%02d%02d%02d_%d.LOG", now.year() % 100, now.month(), now.day(), revisionNumber);
}

void createOrSwitchLogFile() {
  getFilename();
  dataFile = SD.open(filename, FILE_WRITE);

  Serial.println(F("Fichier cree : "));
  Serial.println(filename);

  if (dataFile) {
    Serial.println(F("L'ecriture a demarre"));
  } else {
    Serial.println(F("echec de l'ouverture du fichier"));
  }
}

void InitializeSTAND(){
  Wire.begin();
  //ss.begin(9600);
  dht.begin();

  if (!rtc.begin()) {
    Serial.println(F("Erreur lors de l'initialisation de l'horloge RTC"));
    ERROR[0]=1;
  }

  if (!SD.begin(chipSelect)) {
    Serial.println(F("Erreur lors de l'initialisation de la carte SD"));
    ERROR[4]=1;
  }

  if (dht.readTempAndHumidity(temp_hum_val)){
    Serial.println(F("Erreur lors de l'initialisation du cpt TEMP"));
    ERROR[1]=1;
  }
  // for(int i =0 ; i < sizeof(ERROR)/ERROR[0] ; i++){
  //   Serial.print(ERROR[i]);
  // }
  errorLED(ERROR);
  createOrSwitchLogFile();
}

void Execute(){
  getFilename();
  DateTime now = rtc.now();
  readDHTData(temperature, humidity);
  readLightSensor(luminosity);
  //readGPSLatitudeLongitude(gpsLatitude, gpsLongitude);
  errorLED(ERROR);
  logDataToSD(now, temperature, humidity, luminosity/*, gpsLatitude, gpsLongitude*/);

  createOrSwitchLogFile();
}

/*void readGPSLatitudeLongitude(char* latitude, char* longitude) {
  if (millis() - lastReadTimeSensors <= sensorTimeout) {
    float PROGMEM gpsLat = 0;
    float PROGMEM gpsLong = 0;
    while (Serial.available() > 0) {
      char c = Serial.read();
      if (gps.encode(c)) {
        gps.f_get_position(&gpsLat, &gpsLong);
      }
    }
    if (gpsLat != 0 && gpsLong != 0) {
      snprintf(latitude, 20, "%.6f", gpsLat);
      snprintf(longitude, 20, "%.6f", gpsLong);
    } else {
      strcpy(latitude, "NA");
      strcpy(longitude, "NA");
    }
  } else {
    strcpy(latitude, "NA");
    strcpy(longitude, "NA");
  }
}*/

void readDHTData(char* temp, char* hum) {
  EEPROM.get(22, TEMP_AIR);
  EEPROM.get(23, MIN_TEMP_AIR);
  EEPROM.get(25, MAX_TEMP_AIR);
  EEPROM.get(27, HYGR);
  EEPROM.get(28, HYGR_MINT);
  EEPROM.get(30, HYGR_MAXT);
  if (!dht.readTempAndHumidity(temp_hum_val)) {

    //------------------------VERIFICATION CAPTEUR TEMPERATURE---------------------------
    if(TEMP_AIR == 0){
      strcpy(temp, "DC");
    }else{
      if(temp_hum_val[0] >= MIN_TEMP_AIR && temp_hum_val[0] <= MAX_TEMP_AIR){
        itoa(temp_hum_val[0], temp, 10);
      }else{
        strcpy(temp, "NA");
        ERROR[2]=1;
      }
    }
    //------------------------VERIFICATION CAPTEUR HUMIDITE---------------------------
    if(HYGR == 0){
      strcpy(hum, "DC");
    }else{
      if(temp_hum_val[1] >= HYGR_MINT && temp_hum_val[1] <= HYGR_MAXT){
        itoa(temp_hum_val[1], hum, 10);
      }else{
        strcpy(hum, "NA");
        ERROR[2]=1;
      }
    }
    lastReadTimeSensors = millis();
  } else {
      strcpy(temp, "NA");
      strcpy(hum, "NA");
      ERROR[2]=1;
      lastReadTimeSensors = millis();
  }
}

void readLightSensor(char* lum) {
  EEPROM.get(17, LUMIN);
  EEPROM.get(18, LUMIN_LOW);
  EEPROM.get(20, LUMIN_HIGH);
  int lumValue = analogRead(lightSensorPin);
  //------------------------VERIFICATION CAPTEUR LUMINOSITE---------------------------
  if(LUMIN == 0){
    strcpy(lum, "DC");
  }else{
    if (lumValue >= LUMIN_LOW && lumValue <= LUMIN_HIGH) {
      snprintf(lum, 10, "%d", lumValue);
      lastReadTimeSensors = millis();
  } else {
      strcpy(lum, "NA");
      lastReadTimeSensors = millis();
      ERROR[2]=1;
    }
  }
}

void logDataToSD(DateTime timestamp, char* temp, char* hum, char* lum/*, char* lat, char* lon*/) {
  if (dataFile) {
    dataFile.print(timestamp.day());
    dataFile.print(F("/"));
    dataFile.print(timestamp.month());
    dataFile.print(F("/"));
    dataFile.print(timestamp.year());
    dataFile.print(" ");
    dataFile.print(timestamp.hour());
    dataFile.print(F(":"));
    dataFile.print(timestamp.minute());
    dataFile.print(F(" - Temperature: "));
    dataFile.print(temp);
    dataFile.print(F("°C - Humidite: "));
    dataFile.print(hum);
    dataFile.print(F("% - Luminosite: "));
    dataFile.print(lum);

    // dataFile.print(" - Latitude: ");
    // dataFile.print(lat);
    // dataFile.print(" - Longitude: ");
    // dataFile.print(lon);

    dataFile.println();
    Serial.println(F("Donnees enregistrees dans le fichier"));
    dataFile.close();
  } else {
    Serial.println(F("echec de l'ecriture des donnees dans le fichier"));
    dataFile.close();
  }
}

void errorLED(bool *Errors){
  if(Errors[0] == 1){
    blink2CsLED(error_rtc);
  }
  if(Errors[1] == 1){
    blink2CsLED(error_capt_access);
  }
  if(Errors[2] == 1){
    blink2CsLED(error_capt_weird);
  }
  if(Errors[3] == 1){
    blink2CsLED(error_sd_full);
  }
  if(Errors[4] == 1){
    blink2CsLED(error_sd_access);
  }
  if(Errors[0] == 1 || Errors[1] == 1 || Errors[2] == 1 || Errors[3] == 1 || Errors[4] == 1){
    while(1){
      Serial.println(F("\nERREURS, VERIFIEZ MATERIELS ...\nRESET SI CORRIGE"));
      delay(10000);
    }
  }else{
    return;
  }
}