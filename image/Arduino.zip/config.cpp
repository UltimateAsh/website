#include "config.h"
#include "fonctions.h"

String DataIn;
const char *InputsEquals[] = {"LOG_INTER", "FILE_MAX_SIZE", "TIMEOUT", "LUMIN", "LUMIN_LOW", "LUMIN_HIGH", "TEMP_AIR", "MIN_TEMP_AIR", "MAX_TEMP_AIR", "HYGR", "HYGR_MINT", "HYGR_MAXT"};
const char *Inputs[] = { "RESET", "VERSION", "SEEPARAMS" };
const void (*FuncInputs[])() = {RESET, VERSION, SEEPARAMS};
const void (*FuncInputsEquals[])(int valeur) = { LOG_INTERVAL, FILE_MAX_SIZE, TIMEOUT, LUMIN, LUMIN_LOW, LUMIN_HIGH, TEMP_AIR, MIN_TEMP_AIR, MAX_TEMP_AIR, HYGR, HYGR_MINT, HYGR_MAXT};

unsigned long lastCommandIn = 0;

struct PARAMETERS Default = { 10, 2048, 30, "1.0", 1, 255, 768, 1, -10, 60, 1, 0, 50 };

struct PARAMETERS Read;

bool commandFound = 0;
byte i=0;

// Réception des données envoyées par l'utilisateur à l'arduino

void InitializeEEPROM(){

  const byte isInit = {EEPROM.read(0)};

  if(isInit == 0xFF){
    EEPROM.write(0, 0x00);
    EEPROM.put(1, Default);
    Serial.println(F("WRITING EEPORM."));
  }else{
    Serial.println(F("EEPROM GOOD."));
  }
}

void RecupSerial(void){

  if(Serial.available() > 0){
    while(Serial.available() > 0){

      lastCommandIn = millis();
      char received = Serial.read();

      if(received != '\n'){
        DataIn += received;
      }else{
        DataIn += '\0';
      }
    }

    Interpret(DataIn);
    DataIn="";

  }else{
      EEPROM.get(1, Read);
      long TimeO = Read.TIMEOUT;
      if(millis() - lastCommandIn >= TimeO*1000 /*Read.TIMEOUT*60000*/){
        fromConfigToStand();
      }
  }
}

// Interprétation de ce qui est entré par l'utilisateur

void Interpret(String Input){

  int index = Input.indexOf("=", 0);
  String command; // = Input.substring(0, index);
  String value; // = Input.substring(index+1);

  if(index == -1){
    command = Input;
    commandFound = 0;
    i = 0;
    while(i < sizeof(Inputs)/sizeof(Inputs[0])){
      if(strcmp(Inputs[i], command.c_str()) == 0){
        commandFound = 1;
        break;
      }
      i++;
    }
    command="";
    
    if(commandFound == 1){
      FuncInputs[i]();
      return;
    }else{
      Serial.println(F("Commande introuvable."));
      return;
    }
  }else{
    command = Input.substring(0, index);
    value = Input.substring(index+1);

    commandFound = 0;
    i = 0;

    while(i < sizeof(InputsEquals)/sizeof(InputsEquals[0])){
      if(strcmp(InputsEquals[i], command.c_str()) == 0){
        commandFound = 1;
        break;
      }
      i++;
    }
    command="";
    
    if(commandFound == 1){
      if(value == ""){
        Serial.println(F("Spécifiez params."));
        return;
      }else{
        if(value[0] == '-'){
          for(int i = 1; i < sizeof(value)/sizeof(value[0]); i++){
            if(('0' > value[i] || '9' < value[i]) && value[i] !='\0'){
              Serial.println(F("Erreur paramètres."));
              value = "";
              return;
            }
          }
        }else{
          for(int i = 0; i < sizeof(value)/sizeof(value[0]); i++){
            if(('0' > value[i] || '9' < value[i]) && value[i] !='\0'){
              Serial.println(F("Erreur paramètres."));
              value = "";
              return;
            }
          }
        }
      }
      FuncInputsEquals[i](value.toInt());
      command="";
      value = "";

    }else{
      Serial.println(F("Commande introuvable."));
      command="";
      value = "";
      return;
    }
  }

  
}

//Fonctions sans paramètres

void RESET(){
  EEPROM.put(1, Default);
  Serial.println(F("RESET OK"));
  return;
}

void VERSION(){
  EEPROM.get(1, Read);
  Serial.print(F("Version : "));
  Serial.println(Read.VERSION);
  return;
}

void SEEPARAMS(){
  EEPROM.get(1, Read);
  Serial.print(F("\nLOG_INTERVAL = ")); Serial.println(Read.LOG_INTERVALL);
  Serial.print(F("FILE_MAX_SIZE = ")); Serial.println(Read.FILE_MAX_SIZE);
  Serial.print(F("TIMEOUT = ")); Serial.println(Read.TIMEOUT);
  Serial.println("");
  Serial.print(F("Capteur LUMIN = ")); Serial.println(Read.LUMIN);
  Serial.print(F("LUMIN_LOW = ")); Serial.println(Read.LUMIN_LOW);
  Serial.print(F("LUMIN_HIGH = ")); Serial.println(Read.LUMIN_HIGH);
  Serial.println("");
  Serial.print(F("Capteur TEMP_AIR = ")); Serial.println(Read.TEMP_AIR);
  Serial.print(F("MIN_TEMP_AIR = ")); Serial.println(Read.MIN_TEMP_AIR);
  Serial.print(F("MAX_TEMP_AIR = ")); Serial.println(Read.MAX_TEMP_AIR);
  Serial.println("");
  Serial.print(F("Capteur HYGR = ")); Serial.println(Read.HYGR);
  Serial.print(F("HYGR_MINT = ")); Serial.println(Read.HYGR_MINT);
  Serial.print(F("HYGR_MAXT = ")); Serial.println(Read.HYGR_MAXT);
  return;
}

//Fonctions avec paramères

void LOG_INTERVAL(int valeur){
  if(valeur < 0){
    Serial.println(F("ERR PARAM"));
    return;
  }else{
    int offset = offsetof(PARAMETERS, LOG_INTERVALL)+1;
    EEPROM.put(offset, valeur);
    EEPROM.get(1, Read);
    if(Read.LOG_INTERVALL != valeur){
      Serial.println(F("ERR"));
      return;
    }else{
      Serial.println(F("OK"));
      return;
    }
  }
}

void FILE_MAX_SIZE(int valeur){
  if(valeur < 0 || valeur > 65535){
    Serial.println(F("ERR PARAM"));
    return;
  }else{
    int offset = offsetof(PARAMETERS, FILE_MAX_SIZE) + 1;
    EEPROM.put(offset, valeur);
    EEPROM.get(1, Read);
    if(Read.FILE_MAX_SIZE != valeur){
      Serial.println(F("ERR"));
      return;
    }else{
      Serial.println(F("OK"));
      return;
    }
  }
}

void TIMEOUT(int valeur){
  if(valeur < 0 || valeur > 255){
    Serial.println(F("ERR PARAM"));
    return;
  } else {
    int offset = offsetof(PARAMETERS, TIMEOUT) + 1;
    EEPROM.update(offset, valeur);

    EEPROM.get(1, Read);
    if (Read.TIMEOUT != valeur){
      Serial.println(F("ERR"));
      return;
    } else {
      Serial.println(F("OK"));
      return;
    }
  }
}

void LUMIN(int valeur){
  if (valeur != 0 && valeur != 1){
    Serial.println(F("ERR PARAM"));
    return;
  } else {
    int offset = offsetof(PARAMETERS, LUMIN) + 1;
    EEPROM.update(offset, valeur);

    EEPROM.get(1, Read);
    if (Read.LUMIN != valeur){
      Serial.println(F("ERR"));
      return;
    } else {
      Serial.println(F("OK"));
      return;
    }
  }
}

void LUMIN_LOW(int valeur){
  if(valeur < 0 || valeur > 1023){
    Serial.println(F("ERR PARAM"));
    return;
  } else {
    int offset = offsetof(PARAMETERS, LUMIN_LOW) + 1;
    EEPROM.put(offset, valeur);

    EEPROM.get(1, Read);
    if (Read.LUMIN_LOW != valeur){
      Serial.println(F("ERR"));
      return;
    } else {
      Serial.println(F("OK"));
      return;
    }
  }
}

void LUMIN_HIGH(int valeur){
  if(valeur < 0 || valeur > 1023){
    Serial.println(F("ERR PARAM"));
    return;
  } else {
    int offset = offsetof(PARAMETERS, LUMIN_HIGH) + 1;
    EEPROM.put(offset, valeur);

    EEPROM.get(1, Read);
    if (Read.LUMIN_HIGH != valeur){
      Serial.println(F("ERR"));
      return;
    } else {
      Serial.println(F("OK"));
      return;
    }
  }
}

void TEMP_AIR(int valeur){
  if(valeur !=0 && valeur !=1){
    Serial.println(F("ERR PARAM"));
  }else{
    int offset = offsetof(PARAMETERS, TEMP_AIR) + 1;
    EEPROM.update(offset, valeur);

    EEPROM.get(1, Read);
    if (Read.TEMP_AIR != valeur){
      Serial.println(F("ERR"));
      return;
    } else {
      Serial.println(F("OK"));
      return;
    }
  }
}

void MAX_TEMP_AIR(int valeur){
  if(valeur < -40 || valeur > 85){
    Serial.println(F("ERR PARAM"));
  }else{
    int offset = offsetof(PARAMETERS, MAX_TEMP_AIR) + 1;
    EEPROM.put(offset, valeur);

    EEPROM.get(1, Read);
    if (Read.MAX_TEMP_AIR != valeur){
      Serial.println(F("ERR"));
      return;
    } else {
      Serial.println(F("OK"));
      return;
    }
  }
}

void MIN_TEMP_AIR(int valeur){
  if(valeur < -40 || valeur > 85){
    Serial.println(F("ERR PARAM"));
  }else{
    int offset = offsetof(PARAMETERS, MIN_TEMP_AIR) + 1;
    EEPROM.put(offset, valeur);

    EEPROM.get(1, Read);
    if (Read.MIN_TEMP_AIR != valeur){
      Serial.println(F("ERR"));
      return;
    } else {
      Serial.println(F("OK"));
      return;
    }
  }
}

void HYGR(int valeur){
  if(valeur !=0 && valeur !=1){
    Serial.println(F("ERR PARAM"));
  }else{
    int offset = offsetof(PARAMETERS, HYGR) + 1;
    EEPROM.update(offset, valeur);

    EEPROM.get(1, Read);
    if (Read.HYGR != valeur){
      Serial.println(F("ERR"));
      return;
    } else {
      Serial.println(F("OK"));
      return;
    }
  }
}

void HYGR_MINT(int valeur){
  if(valeur < -40 || valeur > 85){
    Serial.println(F("ERR PARAM"));
  }else{
    int offset = offsetof(PARAMETERS, HYGR_MINT) + 1;
    EEPROM.put(offset, valeur);

    EEPROM.get(1, Read);
    if (Read.HYGR_MINT != valeur){
      Serial.println(F("ERR"));
      return;
    } else {
      Serial.println(F("OK"));
      return;
    }
  }
}

void HYGR_MAXT(int valeur){
  if(valeur < -40 || valeur > 85){
    Serial.println(F("ERR PARAM"));
  }else{
    int offset = offsetof(PARAMETERS, HYGR_MAXT) + 1;
    EEPROM.put(offset, valeur);

    EEPROM.get(1, Read);
    if (Read.HYGR_MAXT != valeur){
      Serial.println(F("ERR"));
      return;
    } else {
      Serial.println(F("OK"));
      return;
    }
  }
}
