#include "Arduino.h"

bool check_change_state(unsigned long *begin);