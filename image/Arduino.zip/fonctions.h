#include "Arduino.h"
#include <ChainableLED.h>

#define BTN_ROUGE 3
#define BTN_VERT 2

//    DEFINITION DE TOUS LES MODES POSSIBLES

typedef enum : byte{
  START, 
  STAND,
  CONF, 
  MAINT, 
  ECO } States;

//    EXPORTATION DE L'ENUM currentState

extern States currentState;
extern States previousState;


//    DECLARATION DES FONCTIONS DANS fonctions.h

void CheckState(void);
void fromConfigToStand();
void blink2CsLED(byte r1, byte g1, byte b1, byte r2, byte g2, byte b2);