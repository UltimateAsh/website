#include "time_check_btns.h"

#define TRESHHOLD 2000

bool check_change_state(unsigned long *begin){

  //Serial.println(*begin);
  
  if(*begin == 0){
    *begin = millis();
    return 0;

  }
  else{
    if(millis() - *begin >= TRESHHOLD){
  
      *begin=0;
      return 1;

    }
    else{

      *begin=0; 
      return 0;

    }
  }
}