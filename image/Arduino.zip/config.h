#include "Arduino.h"
#include <EEPROM.h>

//Définition de la strucute de données

struct PARAMETERS{

  int LOG_INTERVALL;
  int FILE_MAX_SIZE;
  int TIMEOUT;
  char VERSION[10];

  //Capteur de luminosité
  bool LUMIN;
  int LUMIN_LOW;
  int LUMIN_HIGH;

  //Capteur temp. air
  bool TEMP_AIR;
  int MIN_TEMP_AIR;
  int MAX_TEMP_AIR;

  //Capteur hygrométrie
  bool HYGR;
  int HYGR_MINT;
  int HYGR_MAXT;
};

//Fonctions principales
void RecupSerial();
void Interpret(String Input);
void InitializeEEPROM();

//Fonctions sans paramètres

void RESET();
void VERSION();
void SEEPARAMS();


// Fonction avec paramètres

void LOG_INTERVAL(int);
void FILE_MAX_SIZE(int);
void TIMEOUT(int);
void LUMIN(int);
void LUMIN_LOW(int);
void LUMIN_HIGH(int);
void TEMP_AIR(int);
void MAX_TEMP_AIR(int);
void MIN_TEMP_AIR(int);
void HYGR(int);
void HYGR_MINT(int);
void HYGR_MAXT(int);
