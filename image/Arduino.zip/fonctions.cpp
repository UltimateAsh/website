#include "fonctions.h"
#include "time_check_btns.h"

#define NUM_LEDS 1

//    DEFINITION DES VARIALES GENERALES

#define BEGIN_MODE START
#define ROUGE 255, 0, 0
#define STANDARD 0, 255, 0
#define ECONOMIQUE 0, 0, 255
#define MAINTENANCE 236, 25, 0
#define CONFIGURATION 255, 155, 0

ChainableLED leds(7, 8, NUM_LEDS);

bool start = 0;

//   DEFINITION DES VARIABLES DE TEMPS

unsigned long begin_red = 0;
unsigned long begin_green = 0;

States currentState = BEGIN_MODE;
States previousState = BEGIN_MODE;

//    FONCTION QUI PERMET DE CHANGER DE MODE

void CheckState(void) {

  switch (currentState) {

      //----------------------------->[MODE START]<------------------------------------

    case START:

      leds.setColorRGB(0, ROUGE);
      leds.init();
      //Serial.println("Démarrage...");

      if (digitalRead(BTN_ROUGE) == 0) {

        start = 1;
        currentState = CONF;
        previousState = START;

        leds.setColorRGB(0, CONFIGURATION);
        Serial.println(F("Dem .. CONF"));

      } else {

        currentState = STAND;
        previousState = START;
        Serial.println(F("Dem .. STD"));
        leds.setColorRGB(0, STANDARD);
      }
      break;

      //----------------------------->[MODE STANDARD]<------------------------------------

    case STAND:

      /*Serial.print("ROUGE  : ");
      Serial.println(begin_red);

      Serial.print("VERT  : ");
      Serial.println(begin_green);*/

      if (digitalRead(BTN_ROUGE) == 0 || begin_red != 0) {
        if (check_change_state(&begin_red) == 1) {

          Serial.println(F("STD->MT"));
          leds.setColorRGB(0, MAINTENANCE);
          currentState = MAINT;
          previousState = STAND;

          begin_green = 0;
        }
      } else if (digitalRead(BTN_VERT) == 0 || begin_green != 0) {
        if (check_change_state(&begin_green) == 1) {

          Serial.println(F("STD->ECO"));
          leds.setColorRGB(0, ECONOMIQUE);
          currentState = ECO;
          previousState = STAND;
          begin_red = 0;
        }
      }
      break;

    case CONF:

      if (start == 1) {

        start = 0;
        //Serial.println("Start PUT TO 0");

      }

      else {

        //currentState = MAINT;
        //previousState = CONF;
        //leds.setColorRGB(0, CONFIGURATION);
      }

      break;

      //----------------------------->[MODE MAINTENANCE]<------------------------------------

    case MAINT:

      if (digitalRead(BTN_ROUGE) == 0 || begin_red != 0) {
        if (check_change_state(&begin_red) == 1) {
          if (previousState == STAND) {
            currentState = STAND;
            previousState = MAINT;
            Serial.println(F("MT->STD"));
            leds.setColorRGB(0, STANDARD);

          } else if (previousState == ECO) {
            currentState = ECO;
            previousState = MAINT;
            Serial.println(F("MT->ECO"));
            leds.setColorRGB(0, ECONOMIQUE);
          }
        }
      }
      break;

      //----------------------------->[MODE ECONOMIE]<-------------------------------------

    case ECO:

      if (digitalRead(BTN_ROUGE) == 0 || begin_red != 0) {
        if (check_change_state(&begin_red) == 1) {

          Serial.println(F("ECO->STD"));
          leds.setColorRGB(0, STANDARD);
          currentState = STAND;
          previousState = ECO;
          begin_green = 0;
        }
      } else if (digitalRead(BTN_VERT) == 0 || begin_green != 0) {
        if (check_change_state(&begin_green) == 1) {

          Serial.println(F("ECO->MT"));
          leds.setColorRGB(0, MAINTENANCE);
          currentState = MAINT;
          previousState = ECO;
          begin_red = 0;
        }
      }
      break;
  }
}

void fromConfigToStand(){
  currentState = STAND;
  previousState = CONF;
  leds.setColorRGB(0, STANDARD);
  Serial.println(F("CONF->STF (TimeO)"));
}

void blink2CsLED(byte r1, byte g1, byte b1, byte r2, byte g2, byte b2){
  for(byte i = 0; i < 2 ; i++){
    leds.setColorRGB(0, r1, g1, b1);
    delay(1500);
    leds.setColorRGB(0, r2, g2, b2);
    delay(1500);
  }
}
